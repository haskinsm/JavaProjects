import javax.swing.JOptionPane;

public class Test {

	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "Hello");
	}

}
